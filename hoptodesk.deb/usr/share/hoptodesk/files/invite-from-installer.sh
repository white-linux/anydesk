#!/bin/sh

args_of() {
	if [ -r "/proc/$1/cmdline" ]; then
		tr '\0' '\n' < "/proc/$1/cmdline"
	else
		ps -ww -o args= -p "$1" | tr ' ' '\n'
	fi
}

parent_of() {
	if [ -r "/proc/$1/stat" ]; then
		sed 's/.*) //' "/proc/$1/stat" | cut -d' ' -f2
	else
		ps -o ppid= -p "$1" | tr -d ' '
	fi
}

code_from_path() {
	name=$(basename "$1")
	case "$name" in
		*.deb|*.rpm|*.pkg) ;;
		*) return 1 ;;
	esac
	code=${name%.*}
	code=${code##*-}
	printf '%s' "$code" | grep -Eq '^[A-Za-z0-9]{16}$' || return 1
	printf '%s' "$code" | grep -q '[A-Z]' || return 1
	printf '%s' "$code"
}

find_code() {
	pid=$PPID
	for _ in 1 2 3 4 5 6; do
		[ -n "$pid" ] && [ "$pid" -gt 1 ] 2>/dev/null || return 1
		found=$(args_of "$pid" | while IFS= read -r arg; do
			code_from_path "$arg" && break
		done)
		if [ -n "$found" ]; then
			printf '%s' "$found"
			return 0
		fi
		pid=$(parent_of "$pid")
	done
	return 1
}

write_code() {
	dir="$1/hoptodesk"
	grep -Eqs "^last_enrolled_invite_code = [\"']$2[\"']" "$dir/HopToDesk2.toml" && return
	umask 077
	mkdir -p "$dir" && printf '%s' "$2" > "$dir/InviteCode.toml"
}

if [ "$1" = "--write" ]; then
	write_code "$2" "$3"
	exit 0
fi

owner_of() {
	stat -c '%U' "$1" 2>/dev/null || stat -f '%Su' "$1"
}

user_configs() {
	for home in /home/*; do
		echo "$home/.config"
	done
	getent passwd | awk -F: '$3 >= 1000 && $3 < 60000 { print $6 "/.config" }'
	[ -n "$SUDO_USER" ] && getent passwd "$SUDO_USER" | awk -F: '{ print $6 "/.config" }'
}

CODE=$(find_code) || exit 0

mkdir -p /root/.config
write_code /root/.config "$CODE"

user_configs | sort -u | while IFS= read -r parent; do
	[ -d "$parent" ] || continue
	case "$parent" in
		*\'*) continue ;;
	esac
	owner=$(owner_of "$parent")
	[ -n "$owner" ] && [ "$owner" != root ] || continue
	su "$owner" -c "sh '$0' --write '$parent' '$CODE'" >/dev/null 2>&1
done
exit 0
