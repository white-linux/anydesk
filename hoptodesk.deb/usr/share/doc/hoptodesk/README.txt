HopToDesk is a free and open source remote desktop tool for Windows, Mac, Linux, Raspberry Pi, Android and iOS.  Easily share your screen, preform remote assistance, transfer files, and chat with the remote partner.

Traffic is protected by true end-to-end encryption between all connected peers, which means HopToDesk does not have the ability to see user's screens, files, or any information shared between partners during a remote session.

A perfect tool for providing remote support, managing remote servers, and performing remote administration. No complicated setup required, simply download and install HopToDesk on both devices and you are ready to connect.

HopToDesk is free for both personal and business use.